"use strict";
// Websocket based client for koheron-server...
// (c) Koheron
var Driver = /** @class */ (function () {
    function Driver(name, id, cmds) {
        this.name = name;
        this.id = id;
        this.cmds = cmds;
    }
    Driver.prototype.getCmdRef = function (cmdName) {
        for (var _i = 0, _a = this.cmds; _i < _a.length; _i++) {
            var cmd = _a[_i];
            if (cmdName === cmd.name) {
                return cmd.id;
            }
        }
        throw new ReferenceError(cmdName + ': command not found');
    };
    Driver.prototype.getCmds = function () {
        var cmdsDict = {};
        for (var _i = 0, _a = this.cmds; _i < _a.length; _i++) {
            var cmd = _a[_i];
            cmdsDict[cmd.name] = cmd;
        }
        return cmdsDict;
    };
    return Driver;
}());
var WebSocketPool = /** @class */ (function () {
    function WebSocketPool(poolSize, url, onOpenCallback) {
        var _this = this;
        this.poolSize = poolSize;
        this.url = url;
        this.onOpenCallback = onOpenCallback;
        this.poolSize = poolSize;
        this.url = url;
        this.pool = [];
        this.freeSockets = [];
        this.dedicatedSockets = [];
        this.socketCounter = 0;
        this.exiting = false;
        for (var i = 0, end = this.poolSize - 1, asc = 0 <= end; asc ? i <= end : i >= end; asc ? i++ : i--) {
            var websocket = this._newWebSocket();
            this.pool.push(websocket);
            websocket.onopen = function (evt) {
                return _this.waitForConnection(websocket, 100, function () {
                    console.assert(websocket.readyState === 1, 'Websocket not ready');
                    _this.freeSockets.push(_this.socketCounter);
                    if (_this.socketCounter === 0) {
                        onOpenCallback();
                    }
                    websocket.ID = _this.socketCounter;
                    websocket.onclose = function (evt) {
                        setTimeout(function () { location.reload(); }, 1000);
                    };
                    websocket.onerror = function (evt) {
                        console.error("error: ".concat(evt.data, "\n"));
                        return websocket.close();
                    };
                    return _this.socketCounter++;
                });
            };
        }
    }
    WebSocketPool.prototype._newWebSocket = function () {
        var websocket;
        if (typeof window !== 'undefined' && window !== null) {
            websocket = new WebSocket(this.url);
        }
        else { // Node
            var clientConfig = {};
            clientConfig.fragmentOutgoingMessages = false;
            var __WebSocket = require('websocket').w3cwebsocket;
            websocket = new __WebSocket(this.url, null, null, null, null, clientConfig);
        }
        websocket.binaryType = 'arraybuffer';
        return websocket;
    };
    WebSocketPool.prototype.waitForConnection = function (websocket, interval, callback) {
        var _this = this;
        if (websocket.readyState === 1) {
            // If the client has been set to exit while establishing the connection
            // we don't initialize the socket
            if (this.exiting) {
                return;
            }
            return callback();
        }
        else {
            return setTimeout(function () {
                return _this.waitForConnection(websocket, interval, callback);
            }, interval);
        }
    };
    WebSocketPool.prototype.getSocket = function (sockid) {
        if (this.exiting) {
            return null;
        }
        if (!(this.freeSockets.some(function (x) { return x == sockid; })) && (sockid >= 0) && (sockid < this.poolSize)) {
            return this.pool[sockid];
        }
        else {
            throw new ReferenceError("Socket ID ".concat(sockid.toString(), " not available"));
        }
    };
    // Obtain a socket for a dedicated task.
    // This function is provided for long term use.
    // A new socket is opened and returned to the caller.
    // This socket is not shared and can be used for a
    // dedicated task.
    // TODO: Caller close dedicated socket
    WebSocketPool.prototype.getDedicatedSocket = function (callback) {
        var _this = this;
        var websocket = this._newWebSocket();
        this.dedicatedSockets.push(websocket);
        return websocket.onopen = function (evt) {
            return _this.waitForConnection(websocket, 100, function () {
                console.assert(websocket.readyState === 1, 'Websocket not ready');
                websocket.onclose = function (evt) {
                    var idx = _this.dedicatedSockets.indexOf(websocket);
                    if (idx > -1) {
                        return _this.dedicatedSockets.splice(idx, 1);
                    }
                };
                websocket.onerror = function (evt) {
                    console.error("error: ".concat(evt.data, "\n"));
                    return websocket.close();
                };
                return callback(websocket);
            });
        };
    };
    // Retrieve a socket from the pool.
    // This function is provided for short term socket use
    // and the socket must be given back to the pool by
    // calling freeeSocket.
    WebSocketPool.prototype.requestSocket = function (callback) {
        var _this = this;
        if (this.exiting) {
            callback(-1);
            return;
        }
        if ((this.freeSockets != null) && (this.freeSockets.length > 0)) {
            var sockid_1 = this.freeSockets[this.freeSockets.length - 1];
            this.freeSockets.pop();
            return this.waitForConnection(this.pool[sockid_1], 100, function () {
                console.assert(_this.pool[sockid_1].readyState === 1, 'Websocket not ready');
                return callback(sockid_1);
            });
        }
        else { // All sockets are busy. We wait a bit and retry.
            console.assert(this.freeSockets.length === 0, 'Non empty freeSockets');
            return setTimeout(function () {
                return _this.requestSocket(callback);
            }, 100);
        }
    };
    // Give back a socket to the pool
    WebSocketPool.prototype.freeSocket = function (sockid) {
        if (this.exiting) {
            return;
        }
        if (!(this.freeSockets.some(function (x) { return x == sockid; })) && (sockid >= 0) && (sockid < this.poolSize)) {
            return this.freeSockets.push(sockid);
        }
        else {
            if (sockid != null) {
                return console.error("Invalid Socket ID ".concat(sockid.toString()));
            }
            else {
                return console.error('Undefined Socket ID');
            }
        }
    };
    WebSocketPool.prototype.exit = function () {
        this.exiting = true;
        this.freeSockets = [];
        this.socketCounter = 0;
        for (var _i = 0, _a = this.pool; _i < _a.length; _i++) {
            var websocket = _a[_i];
            websocket.close();
        }
        return this.dedicatedSockets.map(function (socket) {
            return socket.close();
        });
    };
    return WebSocketPool;
}());
// === Helper functions to build binary buffer ===
var appendInt8 = function (buffer, value) {
    buffer.push(value & 0xff);
    return 1;
};
var appendUint8 = function (buffer, value) {
    buffer.push(value & 0xff);
    return 1;
};
var appendInt16 = function (buffer, value) {
    buffer.push((value >> 8) & 0xff);
    buffer.push(value & 0xff);
    return 2;
};
var appendUint16 = function (buffer, value) {
    buffer.push((value >> 8) & 0xff);
    buffer.push(value & 0xff);
    return 2;
};
var appendInt32 = function (buffer, value) {
    buffer.push((value >> 24) & 0xff);
    buffer.push((value >> 16) & 0xff);
    buffer.push((value >> 8) & 0xff);
    buffer.push(value & 0xff);
    return 4;
};
var appendUint32 = function (buffer, value) {
    buffer.push((value >> 24) & 0xff);
    buffer.push((value >> 16) & 0xff);
    buffer.push((value >> 8) & 0xff);
    buffer.push(value & 0xff);
    return 4;
};
var floatToBytes = function (f) {
    var buf = new ArrayBuffer(4);
    (new Float32Array(buf))[0] = f;
    return (new Uint32Array(buf))[0];
};
var bytesTofloat = function (bytes) {
    var buffer = new ArrayBuffer(4);
    (new Uint32Array(buffer))[0] = bytes;
    return new Float32Array(buffer)[0];
};
var appendFloat32 = function (buffer, value) { return appendUint32(buffer, floatToBytes(value)); };
var appendFloat64 = function (buffer, value) {
    var buf = new ArrayBuffer(8);
    (new Float64Array(buf))[0] = value;
    appendUint32(buffer, (new Uint32Array(buf, 4))[0]);
    appendUint32(buffer, (new Uint32Array(buf, 0))[0]);
    console.assert(buf.byteLength === 8, 'Invalid float64 size');
    return buf.byteLength;
};
var appendArray = function (buffer, array) {
    var bytes = new Uint8Array(array.buffer);
    return bytes.map(function (_byte) { return buffer.push(_byte); });
};
var appendVector = function (buffer, array) {
    appendUint32(buffer, array.buffer.byteLength);
    var bytes = new Uint8Array(array.buffer);
    return bytes.map(function (_byte) { return buffer.push(_byte); });
};
var appendString = function (buffer, str) {
    appendUint32(buffer, str.length);
    for (var i = 0; i < str.length; i++) {
        buffer.push(str.charCodeAt(i));
    }
};
var isStdArray = function (type) { return type.split('<')[0].trim() === 'std::array'; };
var isStdVector = function (type) { return type.split('<')[0].trim() === 'std::vector'; };
var isStdString = function (type) { return type.trim() === 'std::string'; };
var isStdTuple = function (type) { return type.split('<')[0].trim() === 'std::tuple'; };
var getStdVectorType = function (type) { return type.split('<')[1].split('>')[0].trim(); };
function Command(devId, cmd) {
    var params = [];
    for (var _i = 2; _i < arguments.length; _i++) {
        params[_i - 2] = arguments[_i];
    }
    var buffer = [];
    appendUint32(buffer, 0); // RESERVED
    appendUint16(buffer, devId);
    appendUint16(buffer, cmd.id);
    if (cmd.args.length === 0) {
        return {
            devid: devId,
            cmd: cmd,
            data: new Uint8Array(buffer)
        };
    }
    if (cmd.args.length !== params.length) {
        throw new Error("Invalid number of arguments. Expected ".concat(cmd.args.length, " receive ").concat(params.length, "."));
    }
    var buildPayload = function (args, params) {
        if (args == null) {
            args = [];
        }
        var payload = [];
        for (var i = 0; i < args.length; i++) {
            var arg = args[i];
            switch (arg.type) {
                case 'uint8_t':
                    appendUint8(payload, params[i]);
                    break;
                case 'int8_t':
                    appendInt8(payload, params[i]);
                    break;
                case 'uint16_t':
                    appendUint16(payload, params[i]);
                    break;
                case 'int16_t':
                    appendInt16(payload, params[i]);
                    break;
                case 'uint32_t':
                    appendUint32(payload, params[i]);
                    break;
                case 'int32_t':
                    appendInt32(payload, params[i]);
                    break;
                case 'float':
                    appendFloat32(payload, params[i]);
                    break;
                case 'double':
                    appendFloat64(payload, params[i]);
                    break;
                case 'bool':
                    if (params[i]) {
                        appendUint8(payload, 1);
                    }
                    else {
                        appendUint8(payload, 0);
                    }
                    break;
                default:
                    if (isStdArray(arg.type)) {
                        appendArray(payload, params[i]);
                    }
                    else if (isStdVector(arg.type)) {
                        appendVector(payload, params[i]);
                    }
                    else if (isStdString(arg.type)) {
                        appendString(payload, params[i]);
                    }
                    else {
                        throw new TypeError("Unknown type ".concat(arg.type));
                    }
            }
        }
        return payload;
    };
    return {
        devid: devId,
        cmd: cmd,
        data: new Uint8Array(buffer.concat(buildPayload(cmd.args, params)))
    };
}
var Client = /** @class */ (function () {
    function Client(IP, websockPoolSize) {
        this.IP = IP;
        this.websockPoolSize = websockPoolSize;
        if (websockPoolSize == null) {
            websockPoolSize = 5;
        }
        this.websockPoolSize = websockPoolSize;
        this.url = "ws://".concat(IP, ":8080");
        this.driversList = [];
    }
    Client.prototype.init = function (callback) {
        return this.websockpool = new WebSocketPool(this.websockPoolSize, this.url, (function () {
            return this.loadCmds(callback);
        }.bind(this)));
    };
    Client.prototype.exit = function () {
        this.websockpool.exit();
        return delete this.websockpool;
    };
    // ------------------------
    //  Send
    // ------------------------
    Client.prototype.send = function (cmd) {
        var _this = this;
        if (this.websockpool === null || typeof this.websockpool === 'undefined') {
            return;
        }
        this.websockpool.requestSocket(function (sockid) {
            if (sockid < 0) {
                return;
            }
            var websocket = _this.websockpool.getSocket(sockid);
            websocket.send(cmd.data);
            if (_this.websockpool !== null && typeof _this.websockpool !== 'undefined') {
                _this.websockpool.freeSocket(sockid);
            }
        });
    };
    // ------------------------
    //  Receive
    // ------------------------
    Client.prototype.redirectError = function (errTest, errMsg, onSuccess, onError) {
        if (errTest) {
            if (onError === null) {
                throw new TypeError(errMsg);
            }
            else {
                return onError(errMsg);
            }
        }
        else {
            return onSuccess();
        }
    };
    Client.prototype.getPayload = function (mode, evt) {
        var buffer, dvBuff, i, len;
        var dv = new DataView(evt.data);
        var reserved = dv.getUint32(0);
        var classId = dv.getUint16(4);
        var funcId = dv.getUint16(6);
        if (mode === 'static') {
            len = dv.byteLength - 8;
            buffer = new ArrayBuffer(len);
            dvBuff = new DataView(buffer);
            for (i = 0, end = len - 1, asc = 0 <= end; asc ? i <= end : i >= end; asc ? i++ : i--) {
                var asc, end;
                dvBuff.setUint8(i, dv.getUint8(8 + i));
            }
        }
        else { // 'dynamic'
            len = dv.getUint32(8);
            console.assert(dv.byteLength === (len + 12));
            buffer = new ArrayBuffer(len);
            dvBuff = new DataView(buffer);
            for (i = 0, end1 = len - 1, asc1 = 0 <= end1; asc1 ? i <= end1 : i >= end1; asc1 ? i++ : i--) {
                var asc1, end1;
                dvBuff.setUint8(i, dv.getUint8(12 + i));
            }
        }
        return [dvBuff, classId, funcId];
    };
    Client.prototype._readBase = function (mode, cmd, fn) {
        var _this = this;
        if ((this.websockpool === null || typeof (this.websockpool) === 'undefined')) {
            return fn(null);
        }
        this.websockpool.requestSocket(function (sockid) {
            if (sockid < 0) {
                return fn(null);
            }
            var websocket = _this.websockpool.getSocket(sockid);
            websocket.send(cmd.data);
            websocket.onmessage = function (evt) {
                fn(_this.getPayload(mode, evt)[0]);
                if (_this.websockpool !== null && typeof _this.websockpool !== 'undefined') {
                    _this.websockpool.freeSocket(sockid);
                }
            };
        });
    };
    Client.prototype.readUint32Array = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(new Uint32Array(data.buffer));
        });
    };
    Client.prototype.readInt32Array = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(new Int32Array(data.buffer));
        });
    };
    Client.prototype.readFloat32Array = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(new Float32Array(data.buffer));
        });
    };
    Client.prototype.readFloat64Array = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(new Float64Array(data.buffer));
        });
    };
    Client.prototype.readUint32Vector = function (cmd, fn) {
        this._readBase('dynamic', cmd, function (data) {
            fn(new Uint32Array(data.buffer));
        });
    };
    Client.prototype.readFloat32Vector = function (cmd, fn) {
        this._readBase('dynamic', cmd, function (data) {
            fn(new Float32Array(data.buffer));
        });
    };
    Client.prototype.readFloat64Vector = function (cmd, fn) {
        this._readBase('dynamic', cmd, function (data) {
            fn(new Float64Array(data.buffer));
        });
    };
    Client.prototype.readUint32 = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(data.getUint32(0));
        });
    };
    Client.prototype.readInt32 = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(data.getInt32(0));
        });
    };
    Client.prototype.readFloat32 = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(data.getFloat32(0));
        });
    };
    Client.prototype.readFloat64 = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(data.getFloat64(0));
        });
    };
    Client.prototype.readBool = function (cmd, fn) {
        this._readBase('static', cmd, function (data) {
            fn(data.getUint8(0) === 1);
        });
    };
    Client.prototype.readTuple = function (cmd, fmt, fn) {
        var _this = this;
        this._readBase('static', cmd, function (data) {
            fn(_this.deserialize(fmt, data));
        });
    };
    Client.prototype.deserialize = function (fmt, dv, onError) {
        if (onError == null) {
            onError = null;
        }
        var tuple = [];
        var offset = 0;
        for (var i = 0, end = fmt.length - 1, asc = 0 <= end; asc ? i <= end : i >= end; asc ? i++ : i--) {
            switch (fmt[i]) {
                case 'B':
                    tuple.push(dv.getUint8(offset));
                    offset += 1;
                    break;
                case 'b':
                    tuple.push(dv.getInt8(offset));
                    offset += 1;
                    break;
                case 'H':
                    tuple.push(dv.getUint16(offset));
                    offset += 2;
                    break;
                case 'h':
                    tuple.push(dv.getInt16(offset));
                    offset += 2;
                    break;
                case 'I':
                    tuple.push(dv.getUint32(offset));
                    offset += 4;
                    break;
                case 'i':
                    tuple.push(dv.getInt32(offset));
                    offset += 4;
                    break;
                case 'f':
                    tuple.push(dv.getFloat32(offset));
                    offset += 4;
                    break;
                case 'd':
                    tuple.push(dv.getFloat64(offset));
                    offset += 8;
                    break;
                case '?':
                    if (dv.getUint8(offset) === 0) {
                        tuple.push(false);
                    }
                    else {
                        tuple.push(true);
                    }
                    offset += 1;
                    break;
                default:
                    this.redirectError(true, "Unknown or unsupported type ".concat(fmt[i]), (function () { }), onError);
            }
        }
        return tuple;
    };
    Client.prototype.parseString = function (data, offset) {
        if (offset == null) {
            offset = 0;
        }
        return (__range__(0, data.byteLength - offset - 1, true).map(function (i) { return (String.fromCharCode(data.getUint8(offset + i))); })).join('');
    };
    Client.prototype.readString = function (cmd, fn) {
        var _this = this;
        this._readBase('dynamic', cmd, function (data) {
            fn(_this.parseString(data));
        });
    };
    Client.prototype.readJSON = function (cmd, fn) {
        this.readString(cmd, function (str) {
            fn(JSON.parse(str));
        });
    };
    // ------------------------
    //  Drivers
    // ------------------------
    Client.prototype.loadCmds = function (callback) {
        var _this = this;
        this.readJSON(Command(1, { 'id': 1, 'args': [] }), function (data) {
            for (var _i = 0, data_1 = data; _i < data_1.length; _i++) {
                var driver = data_1[_i];
                var dev = new Driver(driver.class, driver.id, driver.functions);
                // dev.show()
                _this.driversList.push(dev);
            }
            callback();
        });
    };
    Client.prototype.getDriver = function (name) {
        for (var _i = 0, _a = this.driversList; _i < _a.length; _i++) {
            var driver = _a[_i];
            if (driver.name === name) {
                return driver;
            }
        }
        throw new Error("Driver ".concat(name, " not found"));
    };
    Client.prototype.getDriverById = function (id) {
        for (var _i = 0, _a = this.driversList; _i < _a.length; _i++) {
            var driver = _a[_i];
            if (driver.id === id) {
                return driver;
            }
        }
        throw new ReferenceError("Driver ID ".concat(id, " not found"));
    };
    return Client;
}());
;
function __range__(left, right, inclusive) {
    var range = [];
    var ascending = left < right;
    var end = !inclusive ? right : ascending ? right + 1 : right - 1;
    for (var i = left; ascending ? i < end : i > end; ascending ? i++ : i--) {
        range.push(i);
    }
    return range;
}
var Imports = /** @class */ (function () {
    function Imports(document) {
        this.importLinks = document.querySelectorAll('link[rel="import"]');
        for (var i = 0; i < this.importLinks.length; i++) {
            var template = this.importLinks[i].import.querySelector('.template');
            var clone = document.importNode(template.content, true);
            var parentId = this.importLinks[i].dataset.parent;
            document.getElementById(parentId).appendChild(clone);
        }
    }
    return Imports;
}());
var App = /** @class */ (function () {
    function App(window, document, ip, plot_placeholder) {
        var _this = this;
        this.tareOffset = 0;
        this.calibrationFactor = 0.0005;
        var client = new Client(ip, 5);
        window.addEventListener('HTMLImportsLoaded', function () {
            client.init(function () {
                _this.imports = new Imports(document);
                _this.connector = new Connector(client);
                var n_pts = 12192;
                var x_min = 0;
                var x_max = 62.5;
                var y_min = -11;
                var y_max = 11;
                _this.plotBasics = new PlotBasics(document, plot_placeholder, n_pts, x_min, x_max, y_min, y_max, _this.connector, 'setRange', 'Datenpunkt');
                var xLabelSpan = document.getElementById('plot-title');
                xLabelSpan.innerHTML = 'Zeit';
                _this.bindBramTools(document);
                _this.bindScaleTools(document);
                _this.updatePlot();
                _this.updateScaleLoop();
            });
        }, false);
        this.slider = document.getElementById('slider1');
        this.slider.addEventListener('input', function () {
            if (_this.sw.checked) {
                _this.connector.setFunction(1, Number(_this.slider.value));
            }
            else {
                _this.connector.setFunction(0, Number(_this.slider.value));
            }
        });
        window.onbeforeunload = function () {
            client.exit();
        };
    }
    App.prototype.bindBramTools = function (document) {
        var _this = this;
        this.sw = document.getElementById('switch1');
        this.sw.addEventListener('change', function (event) {
            var target = event.target;
            if (target.checked) {
                _this.connector.setFunction(1, Number(_this.slider.value));
            }
            else {
                _this.connector.setFunction(0, Number(_this.slider.value));
            }
        });
        var sw2 = document.getElementById('switch2');
        sw2.addEventListener('change', function (event) {
            var target = event.target;
            if (target.checked) {
                _this.connector.setChannel(1);
            }
            else {
                _this.connector.setChannel(0);
            }
        });
    };
    App.prototype.bindScaleTools = function (document) {
        var _this = this;
        this.adc0LiveEl = document.getElementById('adc0-live');
        this.adc1LiveEl = document.getElementById('adc1-live');
        this.weightEl = document.getElementById('weight-value');
        var calibrationInput = document.getElementById('input-calibration');
        var saveScaleBtn = document.getElementById('btn-save-scale');
        var tareBtn = document.getElementById('btn-tare');
        this.calibrationFactor = this.parseNumber(calibrationInput.value, this.calibrationFactor);
        saveScaleBtn.onclick = function () {
            _this.calibrationFactor = _this.parseNumber(calibrationInput.value, _this.calibrationFactor);
        };
        tareBtn.onclick = function () {
            _this.connector.getAdcRawData(16, function (adc0, _) {
                _this.tareOffset = adc0;
            });
        };
    };
    App.prototype.updatePlot = function () {
        var _this = this;
        this.connector.getDecimatedData(function (plot_data, range_x) {
            _this.plotBasics.redrawRange(plot_data, range_x, 'Spannung', function () {
                requestAnimationFrame(function () {
                    _this.updatePlot();
                });
            });
        });
    };
    App.prototype.updateScaleLoop = function () {
        var _this = this;
        this.connector.getAdcRawData(8, function (adc0, adc1) {
            _this.adc0LiveEl.innerText = adc0.toString();
            _this.adc1LiveEl.innerText = adc1.toString();
            var weight = (adc0 - _this.tareOffset) * _this.calibrationFactor;
            _this.weightEl.innerText = weight.toFixed(3);
            setTimeout(function () {
                _this.updateScaleLoop();
            }, 100);
        });
    };
    App.prototype.parseNumber = function (raw, fallback) {
        var parsed = parseFloat(raw);
        if (isNaN(parsed)) {
            return fallback;
        }
        return parsed;
    };
    return App;
}());
var app = new App(window, document, location.hostname, $('#plot-placeholder'));
var Connector = /** @class */ (function () {
    function Connector(client) {
        this.client = client;
        this.driver = this.client.getDriver('AdcDacBram');
        this.cmds = this.driver.getCmds();
        this.client.send(Command(this.driver.id, this.cmds['set_dac_function'], 0, 1000.0));
        this.channel = 0;
    }
    Connector.prototype.setRange = function (rangeVal) {
    };
    Connector.prototype.setChannel = function (chn) {
        this.channel = chn;
    };
    Connector.prototype.setFunction = function (data, freq) {
        this.client.send(Command(this.driver.id, this.cmds['set_dac_function'], data, freq));
    };
    Connector.prototype.getDecimatedData = function (callback) {
        this.client.readFloat32Vector(Command(this.driver.id, this.cmds['get_decimated_data'], this.channel), function (array) {
            var data = [];
            var range;
            data = new Array(array.length);
            for (var i = 0; i < array.length; i++) {
                data[i] = [i, array[i]];
            }
            range = {
                from: 0,
                to: (array.length - 1)
            };
            callback(data, range);
        });
    };
    Connector.prototype.getAdcRawData = function (nAvg, callback) {
        this.client.readTuple(Command(this.driver.id, this.cmds['get_adc_raw_data'], nAvg), 'ii', function (tup) {
            callback(tup[0], tup[1]);
        });
    };
    return Connector;
}());
// Plot widget
// (c) Koheron
var PlotBasics = /** @class */ (function () {
    function PlotBasics(document, plot_placeholder, n_pts, x_min, x_max, y_min, y_max, driver, rangeFunction, plotTitle) {
        this.plot_placeholder = plot_placeholder;
        this.n_pts = n_pts;
        this.x_min = x_min;
        this.x_max = x_max;
        this.y_min = y_min;
        this.y_max = y_max;
        this.driver = driver;
        this.rangeFunction = rangeFunction;
        this.plotTitle = plotTitle;
        this.isPeakDetection = true;
        this.plotTitleSpan = document.getElementById("plot-title");
        this.plotTitleSpan.textContent = this.plotTitle;
        this.range_x = {};
        this.range_x.from = this.x_min;
        this.range_x.to = this.x_max;
        this.range_y = {};
        this.range_y.from = this.y_min;
        this.range_y.to = this.y_max;
        this.log_y = false;
        this.setPlot(this.range_x.from, this.range_x.to, this.range_y.from, this.range_y.to);
        this.rangeSelect(this.rangeFunction);
        this.dblClick(this.rangeFunction);
        this.onWheel(this.rangeFunction);
        this.showHoverPoint();
        this.showClickPoint();
        this.plotLeave();
        this.reset_range = true;
        this.hoverDatapointSpan = document.getElementById("hover-datapoint");
        this.hoverDatapoint = [];
        this.clickDatapointSpan = document.getElementById("click-datapoint");
        this.clickDatapoint = [];
        this.peakDatapointSpan = document.getElementById("peak-datapoint");
        this.plot_data = [];
        this.LogYaxisFormatter = function (val, axis) { };
        this.initUnitInputs();
        this.initPeakDetection();
    }
    PlotBasics.prototype.setPlot = function (x_min, x_max, y_min, y_max) {
        this.reset_range = false;
        this.options = {
            canvas: true,
            series: {
                shadowSize: 0 // Drawing is faster without shadows
            },
            yaxis: {
                min: y_min,
                max: y_max
            },
            xaxis: {
                min: x_min,
                max: x_max,
                show: true
            },
            grid: {
                margin: {
                    top: 0,
                    left: 0,
                },
                borderColor: "#d5d5d5",
                borderWidth: 1,
                clickable: true,
                hoverable: true,
                autoHighlight: true
            },
            selection: {
                mode: "xy"
            },
            colors: ["#019cd5", "#006400"],
            legend: {
                show: true,
                noColumns: 0,
                labelFormatter: function (label, series) {
                    return "<b style='font-size: 16px; color: #333'>" + label + "\t</b>";
                },
                margin: 0,
                position: "ne",
            }
        };
    };
    PlotBasics.prototype.rangeSelect = function (rangeFunction) {
        var _this = this;
        this.plot_placeholder.bind("plotselected", function (event, ranges) {
            // Clamp the zooming to prevent external zoom
            if (ranges.xaxis.to - ranges.xaxis.from < 0.00001) {
                ranges.xaxis.to = ranges.xaxis.from + 0.00001;
            }
            if (ranges.yaxis.to - ranges.yaxis.from < 0.00001) {
                ranges.yaxis.to = ranges.yaxis.from + 0.00001;
            }
            _this.range_x.from = ranges.xaxis.from;
            _this.range_x.to = ranges.xaxis.to;
            _this.range_y.from = ranges.yaxis.from;
            _this.range_y.to = ranges.yaxis.to;
            if (rangeFunction.length > 0) {
                _this.driver[rangeFunction](ranges.xaxis);
            }
            _this.reset_range = true;
        });
    };
    // A double click on the plot resets to full span
    PlotBasics.prototype.dblClick = function (rangeFunction) {
        var _this = this;
        this.plot_placeholder.bind("dblclick", function (evt) {
            _this.range_x.from = _this.x_min;
            _this.range_x.to = _this.x_max;
            _this.range_y = {};
            if (rangeFunction.length > 0) {
                _this.driver[rangeFunction](_this.range_x);
            }
            _this.reset_range = true;
        });
    };
    PlotBasics.prototype.setRangeX = function (from, to) {
        this.range_x.from = from;
        this.range_x.to = to;
        this.reset_range = true;
    };
    PlotBasics.prototype.setLogX = function () {
        this.options.xaxis.ticks = [0.001, 0.01, 0.1, 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000];
        this.options.xaxis.tickDecimals = 0;
        this.options.xaxis.transform = function (v) { return v > 0 ? Math.log10(v) : null; };
        this.options.xaxis.inverseTransform = function (v) { return v != null ? Math.pow(10, v) : 0.0; };
        this.options.xaxis.tickFormatter = function (val, axis) {
            if (val >= 1E6) {
                return (val / 1E6).toFixed(axis.tickDecimals) + "M";
            }
            else if (val >= 1E3) {
                return (val / 1E3).toFixed(axis.tickDecimals) + "k";
            }
            else {
                return val.toFixed(axis.tickDecimals);
            }
        };
    };
    PlotBasics.prototype.setLogY = function () {
        this.log_y = true;
        this.range_y = {};
        this.reset_range = true;
    };
    PlotBasics.prototype.setLinY = function () {
        this.log_y = false;
        this.range_y = {};
        this.reset_range = true;
    };
    PlotBasics.prototype.updateDatapointSpan = function (datapoint, datapointSpan) {
        var positionX = (this.plot.pointOffset({ x: datapoint[0], y: datapoint[1] })).left;
        var positionY = (this.plot.pointOffset({ x: datapoint[0], y: datapoint[1] })).top;
        datapointSpan.innerHTML = "(" + (datapoint[0].toFixed(2)).toString() + "," + datapoint[1].toFixed(2).toString() + ")";
        if (datapoint[0] < (this.range_x.from + this.range_x.to) / 2) {
            datapointSpan.style.left = (positionX + 5).toString() + "px";
        }
        else {
            datapointSpan.style.left = (positionX - 140).toString() + "px";
        }
        if (datapoint[1] < ((this.range_y.from + this.range_y.to) / 2)) {
            datapointSpan.style.top = (positionY - 50).toString() + "px";
        }
        else {
            datapointSpan.style.top = (positionY + 5).toString() + "px";
        }
    };
    PlotBasics.prototype.redraw = function (plot_data, n_pts, peakDatapoint, ylabel, callback) {
        var _this = this;
        var plt_data = [{ label: ylabel, data: plot_data }];
        if (this.reset_range) {
            if (this.log_y) {
                // /!\ Cannot set ticks lower than 1 /!\
                this.options.yaxis.ticks = [1, 10, 100, 1E3, 1E4, 1E5, 1E6, 1E7, 1E8, 1E9];
                this.options.yaxis.tickDecimals = 0;
                this.options.yaxis.transform = function (v) { return v > 0 ? Math.log10(v) : null; };
                this.options.yaxis.inverseTransform = function (v) { return v != null ? Math.pow(10, v) : 0.0; };
                this.options.yaxis.tickFormatter = this.LogYaxisFormatter;
            }
            else {
                this.options.yaxis = {
                    min: this.range_y.from,
                    max: this.range_y.to
                };
            }
            this.options.xaxis.min = this.range_x.from;
            this.options.xaxis.max = this.range_x.to;
            this.options.yaxis.min = this.range_y.from;
            this.options.yaxis.max = this.range_y.to;
            this.plot = $.plot(this.plot_placeholder, plt_data, this.options);
            this.plot.setupGrid();
            this.range_y.from = this.plot.getAxes().yaxis.min;
            this.range_y.to = this.plot.getAxes().yaxis.max;
            this.reset_range = false;
        }
        else {
            this.plot.setData(plt_data);
            this.plot.draw();
        }
        var localData = this.plot.getData();
        setTimeout(function () { _this.plot.unhighlight(); }, 100);
        if (this.clickDatapoint.length > 0) {
            var i = void 0;
            for (i = 0; i < plot_data.length; i++) {
                if (localData[0]['data'][i][0] > this.clickDatapoint[0]) {
                    break;
                }
            }
            var p1 = localData[0]['data'][i - 1];
            var p2 = localData[0]['data'][i];
            if ((p1 === null) || (p1 === undefined)) {
                this.clickDatapoint[1] = p2[1];
            }
            else if ((p2 === null) || (p2 === undefined)) {
                this.clickDatapoint[1] = p1[1];
            }
            else {
                this.clickDatapoint[1] = p1[1] + (p2[1] - p1[1]) * (this.clickDatapoint[0] - p1[0]) / (p2[0] - p1[0]);
            }
            if (this.range_x.from < this.clickDatapoint[0] && this.clickDatapoint[0] < this.range_x.to
                && this.range_y.from < this.clickDatapoint[1] && this.clickDatapoint[1] < this.range_y.to) {
                this.updateDatapointSpan(this.clickDatapoint, this.clickDatapointSpan);
                this.clickDatapointSpan.style.display = "inline-block";
                this.plot.highlight(localData[0], this.clickDatapoint);
            }
            else {
                this.clickDatapointSpan.style.display = "none";
            }
        }
        if (this.isPeakDetection && peakDatapoint.length > 0) {
            for (var i = 0; i < plot_data.length; i++) {
                if (peakDatapoint[1] < plot_data[i][1]) {
                    peakDatapoint[0] = plot_data[i][0];
                    peakDatapoint[1] = plot_data[i][1];
                }
            }
            this.plot.unhighlight(localData[0], peakDatapoint);
            if (this.range_x.from < peakDatapoint[0] && peakDatapoint[0] < this.range_x.to
                && this.range_y.from < peakDatapoint[1] && peakDatapoint[1] < this.range_y.to) {
                this.updateDatapointSpan(peakDatapoint, this.peakDatapointSpan);
                this.plot.highlight(localData[0], peakDatapoint);
                this.peakDatapointSpan.style.display = "inline-block";
            }
            else {
                this.plot.unhighlight(localData[0], peakDatapoint);
                this.peakDatapointSpan.style.display = "none";
            }
        }
        else {
            this.plot.unhighlight(localData[0], peakDatapoint);
            this.peakDatapointSpan.style.display = "none";
        }
        callback();
    };
    PlotBasics.prototype.redrawRange = function (data, range_x, ylabel, callback) {
        var plt_data = [{ label: ylabel, data: data }];
        if (data.length == 0) {
            callback();
            return;
        }
        if (this.reset_range) {
            this.options.xaxis.min = range_x.from;
            this.options.xaxis.max = range_x.to;
            this.options.yaxis.min = this.range_y.from;
            this.options.yaxis.max = this.range_y.to;
            this.plot = $.plot(this.plot_placeholder, plt_data, this.options);
            this.plot.setupGrid();
            this.reset_range = false;
        }
        else {
            this.plot.setData(plt_data);
            this.plot.draw();
        }
        callback();
    };
    PlotBasics.prototype.redrawTwoChannels = function (ch0, ch1, range_x, label1, label2, is_channel_1, is_channel_2, callback) {
        if (ch0.length === 0 || ch1.length === 0) {
            callback();
            return;
        }
        var plotCh0 = [];
        var plotCh1 = [];
        if (is_channel_1 && is_channel_2) {
            plotCh0 = ch0;
            plotCh1 = ch1;
            // plotData = [ch0, ch1];
        }
        else if (is_channel_1 && !is_channel_2) {
            plotCh0 = ch0;
            plotCh1 = [];
        }
        else if (!is_channel_1 && is_channel_2) {
            plotCh0 = [];
            plotCh1 = ch1;
        }
        else {
            plotCh0 = [];
            plotCh1 = [];
        }
        var plt_data = [{ label: label1, data: plotCh0 }, { label: label2, data: plotCh1 }];
        if (this.reset_range) {
            this.options.xaxis.min = range_x.from;
            this.options.xaxis.max = range_x.to;
            this.options.yaxis.min = this.range_y.from;
            this.options.yaxis.max = this.range_y.to;
            this.plot = $.plot(this.plot_placeholder, plt_data, this.options);
            this.plot.setupGrid();
            this.reset_range = false;
        }
        else {
            this.plot.setData(plt_data);
            this.plot.draw();
        }
        callback();
    };
    PlotBasics.prototype.onWheel = function (rangeFunction) {
        var _this = this;
        this.plot_placeholder.bind("wheel", function (evt) {
            var delta = evt.originalEvent.deltaX
                + evt.originalEvent.deltaY;
            delta /= Math.abs(delta);
            var zoomRatio = 0.2;
            if (evt.originalEvent.shiftKey) { // Zoom Y
                var positionY = evt.originalEvent.pageY - _this.plot.offset().top;
                var y0 = _this.plot.getAxes().yaxis.c2p(positionY);
                _this.range_y = {
                    from: y0 - (1 + zoomRatio * delta) * (y0 - _this.plot.getAxes().yaxis.min),
                    to: y0 - (1 + zoomRatio * delta) * (y0 - _this.plot.getAxes().yaxis.max)
                };
                _this.reset_range = true;
                return false;
            }
            else if (evt.originalEvent.altKey) { // Zoom X
                var positionX = evt.originalEvent.pageX - _this.plot.offset().left;
                var x0 = _this.plot.getAxes().xaxis.c2p(positionX);
                if (x0 < 0 || x0 > _this.x_max) {
                    return;
                }
                _this.range_x = {
                    from: Math.max(x0 - (1 + zoomRatio * delta) * (x0 - _this.plot.getAxes().xaxis.min), 0),
                    to: Math.min(x0 - (1 + zoomRatio * delta) * (x0 - _this.plot.getAxes().xaxis.max), _this.x_max)
                };
                if (rangeFunction.length > 0) {
                    _this.driver[rangeFunction](_this.range_x);
                }
                _this.reset_range = true;
                return false;
            }
            return true;
        });
    };
    PlotBasics.prototype.initUnitInputs = function () {
        var _this = this;
        var unitInputs = document.getElementsByClassName("unit-input");
        for (var i = 0; i < unitInputs.length; i++) {
            unitInputs[i].addEventListener('change', function (event) {
                _this.reset_range = true;
            });
        }
    };
    PlotBasics.prototype.initPeakDetection = function () {
        var _this = this;
        var peakInputs = document.getElementsByClassName("peak-input");
        for (var i = 0; i < peakInputs.length; i++) {
            peakInputs[i].addEventListener('change', function (event) {
                if (_this.isPeakDetection) {
                    _this.isPeakDetection = false;
                }
                else {
                    _this.isPeakDetection = true;
                }
            });
        }
    };
    PlotBasics.prototype.showHoverPoint = function () {
        var _this = this;
        this.plot_placeholder.bind("plothover", function (event, pos, item) {
            if (item) {
                _this.hoverDatapoint[0] = item.datapoint[0];
                _this.hoverDatapoint[1] = item.datapoint[1];
                _this.hoverDatapointSpan.style.display = "inline-block";
                _this.updateDatapointSpan(_this.hoverDatapoint, _this.hoverDatapointSpan);
            }
            else {
                _this.hoverDatapointSpan.style.display = "none";
            }
        });
    };
    PlotBasics.prototype.showClickPoint = function () {
        var _this = this;
        this.plot_placeholder.bind("plotclick", function (event, pos, item) {
            if (item) {
                _this.clickDatapoint[0] = item.datapoint[0];
                _this.clickDatapoint[1] = item.datapoint[1];
                _this.clickDatapointSpan.style.display = "inline-block";
                _this.updateDatapointSpan(_this.clickDatapoint, _this.clickDatapointSpan);
                _this.plot.unhighlight();
                _this.plot.highlight(item.series, _this.clickDatapoint);
            }
        });
    };
    PlotBasics.prototype.plotLeave = function () {
        var _this = this;
        this.plot_placeholder.bind("mouseleave", function (event, pos, item) {
            _this.hoverDatapointSpan.style.display = "none";
        });
    };
    return PlotBasics;
}());
